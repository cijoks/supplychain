package com.ust.supplychain.services.rest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.bson.Document;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.sun.jersey.spi.resource.Singleton;

@Singleton
@Path("trade-item")
public class TradeItemService {
	
	@Inject
	@Named("mongo.connection.uri")
	private String connectionUri = null;
	
	@Inject
	@Named("mongo.connection.uri")
	private String password = null;

	@GET
	@Produces("application/json")
	public Response getGlobalTradeItem() {

		MongoClientURI uri = new MongoClientURI(connectionUri);

		MongoClient mongoClient = new MongoClient(uri);
		MongoDatabase database = mongoClient.getDatabase("catalog");

		MongoCollection<Document> table = database.getCollection("items");
		Map<String, Object> map = new HashMap<>();
		map.put("_id", "3ZZVA46759401P");
		map.put("company", "Dhi");
		
		table.insertOne(new Document(map ));
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put("_id", "3ZZVA46759401P");

		FindIterable<Document> cursor = table.find(searchQuery);
		Iterator it = cursor.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

		return Response.ok("dfhsdgfjsgk" + "\n").build();
	}
}
